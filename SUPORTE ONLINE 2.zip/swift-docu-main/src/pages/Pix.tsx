import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { QRCodeSVG } from 'qrcode.react';
import { Copy, Check, FileText, Loader2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { getUserData, getMeta, getCheckout, saveMeta } from '@/lib/storage';
export default function Pix() {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const userData = getUserData();
  const meta = getMeta();
  const checkout = getCheckout();
  useEffect(() => {
    if (!userData || !meta) {
      navigate('/iniciar');
    }
  }, [userData, meta, navigate]);
  if (!userData || !meta) return null;
  const pixCode = `00020126580014br.gov.bcb.pix0136${meta.protocolo}5204000053039865406${checkout.valor.toFixed(2)}5802BR5925SISTEMA PROCESSAMENTO6009SAO PAULO62070503***63041234`;
  const handleCopy = async () => {
    await navigator.clipboard.writeText(pixCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const handleConfirm = async () => {
    setConfirming(true);

    // Simulate payment confirmation
    await new Promise(resolve => setTimeout(resolve, 2000));
    saveMeta({
      ...meta,
      paid: true,
      paidAt: new Date().toISOString()
    });
    navigate('/confirmacao');
  };
  return <div className="min-h-screen gradient-hero">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
              <FileText className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground">Suporte Online</span>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                <ArrowLeft className="w-4 h-4 mr-1" />
                Voltar
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Certeza que quer voltar?</AlertDialogTitle>
                <AlertDialogDescription className="space-y-2">
                  <p>Seu documento está pronto para liberação.</p>
                  <p className="font-semibold text-destructive text-center">
                    Atenção: Este documento só poderá ser solicitado novamente após 24 horas nos órgãos responsáveis.
                  </p>
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogAction onClick={() => {}}>Continuar aqui</AlertDialogAction>
                <AlertDialogCancel onClick={() => navigate('/')} className="border-destructive text-destructive hover:bg-destructive/10">
                  Descartar Documento e Voltar
                </AlertDialogCancel>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-lg">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} className="bg-card rounded-2xl shadow-elevated border border-border/50 p-6 md:p-8">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4">
              <svg viewBox="0 0 24 24" className="w-8 h-8 text-primary-foreground" fill="currentColor">
                <path d="M15.5 8.5c-.28 0-.5.22-.5.5v6c0 .28.22.5.5.5s.5-.22.5-.5V9c0-.28-.22-.5-.5-.5zm-7 0c-.28 0-.5.22-.5.5v6c0 .28.22.5.5.5s.5-.22.5-.5V9c0-.28-.22-.5-.5-.5zM12 7.5c-.28 0-.5.22-.5.5v8c0 .28.22.5.5.5s.5-.22.5-.5V8c0-.28-.22-.5-.5-.5z" />
                <path d="M21.5 12c0-1.38-.56-2.63-1.46-3.54L15.5 4l-3.5 3.5L8.5 4 4 8.46C3.1 9.37 2.5 10.62 2.5 12s.56 2.63 1.46 3.54L8.5 20l3.5-3.5 3.5 3.5 4.5-4.46c.94-.91 1.5-2.16 1.5-3.54z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-1">Pagamento Pix</h1>
            <p className="text-muted-foreground text-sm">Escaneie o QR Code ou copie o código</p>
          </div>

          {/* Protocol & Value */}
          <div className="bg-secondary/50 rounded-xl p-4 mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">Protocolo</span>
              <span className="font-mono font-bold text-primary">{meta.protocolo}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Valor</span>
              <span className="text-xl font-bold text-foreground">
                R$ {checkout.valor.toFixed(2).replace('.', ',')}
              </span>
            </div>
          </div>

          {/* QR Code */}
          <div className="bg-card border border-border rounded-xl p-6 mb-6">
            <div className="flex justify-center">
              <div className="bg-card p-4 rounded-xl border border-border">
                <QRCodeSVG value={pixCode} size={180} level="H" bgColor="white" fgColor="hsl(222, 47%, 11%)" />
              </div>
            </div>
          </div>

          {/* Copy Button */}
          <Button variant="outline" onClick={handleCopy} className="w-full mb-4 py-5 border-2">
            {copied ? <>
                <Check className="w-4 h-4 mr-2 text-success" />
                Código copiado!
              </> : <>
                <Copy className="w-4 h-4 mr-2" />
                Copiar código Pix
              </>}
          </Button>

          {/* Confirm Button */}
          <Button size="lg" onClick={handleConfirm} disabled={confirming} className="w-full gradient-primary text-primary-foreground py-6 text-lg font-semibold shadow-soft hover:shadow-elevated transition-all duration-300">
            {confirming ? <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Confirmando pagamento...
              </> : 'Confirmar pagamento'}
          </Button>

          <p className="text-xs text-center text-muted-foreground mt-4">
            Clique em confirmar após realizar o pagamento
          </p>
        </motion.div>
      </div>
    </div>;
}