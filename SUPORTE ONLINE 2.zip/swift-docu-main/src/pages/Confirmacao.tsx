import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle2, Mail, Clock, MessageCircle, FileText, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getUserData, getMeta, saveMeta } from '@/lib/storage';
export default function Confirmacao() {
  const navigate = useNavigate();
  const [sending, setSending] = useState(true);
  const userData = getUserData();
  const meta = getMeta();
  useEffect(() => {
    if (!userData || !meta || !meta.paid) {
      navigate('/iniciar');
      return;
    }

    // Simulate sending to platform
    const timer = setTimeout(() => {
      saveMeta({
        ...meta,
        sentToPlatform: true
      });
      setSending(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, [userData, meta, navigate]);
  if (!userData || !meta) return null;
  return <div className="min-h-screen gradient-hero">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
            <FileText className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-foreground">Suporte Online</span>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-lg">
        <motion.div initial={{
        opacity: 0,
        scale: 0.95
      }} animate={{
        opacity: 1,
        scale: 1
      }} className="bg-card rounded-2xl shadow-elevated border border-border/50 p-6 md:p-8 text-center">
          {/* Success Icon */}
          <motion.div initial={{
          scale: 0
        }} animate={{
          scale: 1
        }} transition={{
          type: 'spring',
          stiffness: 200,
          damping: 15,
          delay: 0.2
        }} className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-success" />
          </motion.div>

          <motion.h1 initial={{
          opacity: 0,
          y: 10
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.3
        }} className="text-2xl font-bold text-foreground mb-2">
            Obrigado!
          </motion.h1>

          {/* Status Badge */}
          <motion.div initial={{
          opacity: 0,
          y: 10
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.4
        }} className="inline-flex items-center gap-2 bg-success/10 text-success px-4 py-2 rounded-full text-sm font-medium mb-6">
            {sending ? <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Encaminhando para plataforma...
              </> : <>
                <CheckCircle2 className="w-4 h-4" />
                Encaminhado para Verificação
              </>}
          </motion.div>

          {/* Info Card */}
          <motion.div initial={{
          opacity: 0,
          y: 10
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.5
        }} className="bg-secondary/50 rounded-xl p-4 mb-6 text-left">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Protocolo</p>
                  <p className="font-mono font-bold text-primary">{meta.protocolo}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">E-mail de envio</p>
                  <p className="font-medium text-foreground">{userData.email}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Prazo estimado</p>
                  <p className="font-medium text-foreground">Até 30 minutos </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Info Text */}
          <motion.p initial={{
          opacity: 0
        }} animate={{
          opacity: 1
        }} transition={{
          delay: 0.6
        }} className="text-sm text-muted-foreground mb-6">
            O documento será encaminhado para o e-mail informado. Aguarde o recebimento.
          </motion.p>

          {/* Support Button */}
          <motion.div initial={{
          opacity: 0,
          y: 10
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.7
        }}>
            <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
              Voltar ao início
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </div>;
}