import { CheckCircle, Mail, MessageCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
export default function Obrigado() {
  const navigate = useNavigate();
  return <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Voltar ao início
          </button>
        </div>
      </header>

      <main className="container py-12 md:py-20">
        <div className="max-w-xl mx-auto text-center">
          {/* Success Icon */}
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 text-green-600 mb-6">
            <CheckCircle className="w-10 h-10" />
          </div>

          {/* Title */}
          <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-4">
            Solicitação Recebida!
          </h1>
          
          <p className="text-lg text-muted-foreground mb-8">
            Obrigado por confiar em nosso serviço. Sua solicitação foi registrada com sucesso.
          </p>

          {/* Info Card */}
          <div className="bg-card border border-border rounded-xl p-6 md:p-8 shadow-sm text-left mb-8">
            <h2 className="font-semibold text-foreground mb-4 text-center">
              Próximos passos
            </h2>
            
            <div className="space-y-4">
              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 font-semibold text-sm">
                  1
                </div>
                <div>
                  <p className="font-medium text-foreground">Confirmação do pagamento</p>
                  <p className="text-sm text-muted-foreground">
                    Estamos verificando seu pagamento. Isso pode levar alguns minutos.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 font-semibold text-sm">
                  2
                </div>
                <div>
                  <p className="font-medium text-foreground">Análise da solicitação</p>
                  <p className="text-sm text-muted-foreground">
                    Nossa equipe irá processar sua solicitação com prioridade.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 font-semibold text-sm">
                  3
                </div>
                <div>
                  <p className="font-medium text-foreground">Retorno em até 2 horas</p>
                  <p className="text-sm text-muted-foreground">
                    Você receberá o resultado por e-mail ou WhatsApp.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Info */}
          <div className="bg-muted/50 rounded-xl p-6 mb-8">
            <p className="text-sm text-muted-foreground mb-4">
              Precisa de ajuda? Entre em contato:
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a href="mailto:contato@assistenciafederal.com.br" className="inline-flex items-center justify-center gap-2 text-sm text-primary hover:underline">
                <Mail className="w-4 h-4" />
                contato@assistenciafederal.com.br
              </a>
              <a href="https://wa.me/5511999999999" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 text-sm text-green-600 hover:underline">
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
            </div>
          </div>

          {/* Back Button */}
          <Button onClick={() => navigate("/")} variant="outline" className="px-8">
            Voltar ao início
          </Button>

          {/* Notice */}
          <p className="text-xs text-muted-foreground mt-8 max-w-md mx-auto">
            Este é um serviço privado de assistência. Guarde esta página como comprovante da sua solicitação.
          </p>
        </div>
      </main>
    </div>;
}