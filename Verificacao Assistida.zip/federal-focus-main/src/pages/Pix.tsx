import { Copy, CheckCircle, ArrowLeft, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
export default function Pix() {
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();

  // PIX key placeholder - replace with actual key
  const pixKey = "contato@assistenciafederal.com.br";
  const pixCode = "00020126580014br.gov.bcb.pix0136exemplo-pix-code-aqui5204000053039865802BR5925ASSISTENCIA FEDERAL6009SAO PAULO62070503***6304ABCD";
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };
  const handleConfirmPayment = () => {
    navigate("/obrigado");
  };
  return <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Voltar ao início
          </button>
        </div>
      </header>

      <main className="container py-12 md:py-20">
        <div className="max-w-xl mx-auto">
          {/* Title */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 text-accent mb-4">
              <Clock className="w-8 h-8" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              Pagamento via PIX
            </h1>
            <p className="text-muted-foreground">
              Realize o pagamento para dar continuidade ao seu atendimento
            </p>
          </div>

          {/* Payment Card */}
          <div className="bg-card border border-border rounded-xl p-6 md:p-8 shadow-sm">
            {/* Value */}
            <div className="text-center mb-8 pb-6 border-b border-border">
              <p className="text-sm text-muted-foreground mb-1">Valor do serviço</p>
              <p className="text-4xl font-bold text-foreground">R$ 39,90</p>
            </div>

            {/* QR Code Placeholder */}
            <div className="flex justify-center mb-6">
              <div className="w-48 h-48 bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                <div className="text-center p-4">
                  <p className="text-xs text-muted-foreground">QR Code PIX</p>
                  <p className="text-xs text-muted-foreground mt-1">(Escaneie com seu banco)</p>
                </div>
              </div>
            </div>

            {/* PIX Key */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Chave PIX (E-mail)
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-muted rounded-lg px-4 py-3 text-sm text-foreground font-mono break-all">
                    {pixKey}
                  </div>
                  <Button variant="outline" size="icon" onClick={() => handleCopy(pixKey)} className="shrink-0">
                    {copied ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Código PIX Copia e Cola
                </label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-muted rounded-lg px-4 py-3 text-xs text-muted-foreground font-mono break-all max-h-20 overflow-y-auto">
                    {pixCode}
                  </div>
                  <Button variant="outline" size="icon" onClick={() => handleCopy(pixCode)} className="shrink-0">
                    {copied ? <CheckCircle className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="mt-6 p-4 bg-accent/5 rounded-lg border border-accent/20">
              <h3 className="font-medium text-foreground mb-2 text-sm">Como pagar:</h3>
              <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                <li>Abra o app do seu banco</li>
                <li>Escolha pagar via PIX</li>
                <li>Escaneie o QR Code ou cole o código</li>
                <li>Confirme o pagamento</li>
              </ol>
            </div>

            {/* Confirm Button */}
            <Button onClick={handleConfirmPayment} className="w-full mt-6 bg-accent hover:bg-accent/90 text-accent-foreground py-6 text-lg font-semibold">
              Já realizei o pagamento
            </Button>

            <p className="text-xs text-center text-muted-foreground mt-4">
              Após a confirmação do pagamento, você receberá um e-mail com os próximos passos.
            </p>
          </div>

          {/* Security Notice */}
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              🔒 Pagamento seguro • Seus dados estão protegidos
            </p>
          </div>
        </div>
      </main>
    </div>;
}