import { Headphones, Mail, MessageCircle } from "lucide-react";
export function SupportSection() {
  return <section className="py-16 bg-muted">
      <div className="container">
        <div className="max-w-2xl mx-auto text-center">
          <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Headphones className="w-7 h-7 text-primary" />
          </div>
          
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Suporte humanizado
          </h2>
          
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            Nossa equipe está disponível para esclarecer dúvidas e auxiliar durante todo o processo.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="mailto:contato@verificacaoassistida.com.br" className="flex items-center gap-2 px-5 py-3 bg-card border border-border rounded-lg hover:border-primary/30 transition-colors">
              <Mail className="w-5 h-5 text-primary" />
              <span className="text-foreground">contato@verificacaoassistida.com.br</span>
            </a>
            
            <a href="https://wa.me/5511999999999" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-5 py-3 bg-card border border-border rounded-lg hover:border-accent/30 transition-colors">
              <MessageCircle className="w-5 h-5 text-accent" />
              <span className="text-foreground">(11) 94392-5211</span>
            </a>
          </div>
        </div>
      </div>
    </section>;
}