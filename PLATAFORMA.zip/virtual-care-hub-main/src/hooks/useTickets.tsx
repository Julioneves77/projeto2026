import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Ticket, HistoricoItem, TicketStatus } from '@/types';
import { ticketsMock } from '@/data/mockData';

interface TicketsContextType {
  tickets: Ticket[];
  updateTicket: (id: string, updates: Partial<Ticket>) => void;
  addHistorico: (ticketId: string, item: Omit<HistoricoItem, 'id'>) => void;
  atribuirTicket: (ticketId: string, operador: string) => void;
}

const TicketsContext = createContext<TicketsContextType | undefined>(undefined);

const TICKETS_KEY = 'av_tickets';

export function TicketsProvider({ children }: { children: ReactNode }) {
  const [tickets, setTickets] = useState<Ticket[]>([]);

  useEffect(() => {
    // Força reset para pegar novos mock data
    const stored = localStorage.getItem(TICKETS_KEY);
    const storedVersion = localStorage.getItem('av_tickets_version');
    const currentVersion = '2'; // Incrementar quando mudar mockData
    
    if (stored && storedVersion === currentVersion) {
      const parsed = JSON.parse(stored);
      // Converter strings de data de volta para objetos Date
      const ticketsWithDates = parsed.map((t: any) => ({
        ...t,
        dataCadastro: new Date(t.dataCadastro),
        dataAtribuicao: t.dataAtribuicao ? new Date(t.dataAtribuicao) : null,
        dataConclusao: t.dataConclusao ? new Date(t.dataConclusao) : null,
        historico: t.historico.map((h: any) => ({
          ...h,
          dataHora: new Date(h.dataHora)
        }))
      }));
      setTickets(ticketsWithDates);
    } else {
      setTickets(ticketsMock);
      localStorage.setItem(TICKETS_KEY, JSON.stringify(ticketsMock));
      localStorage.setItem('av_tickets_version', currentVersion);
    }
  }, []);

  const saveTickets = (newTickets: Ticket[]) => {
    setTickets(newTickets);
    localStorage.setItem(TICKETS_KEY, JSON.stringify(newTickets));
  };

  const updateTicket = (id: string, updates: Partial<Ticket>) => {
    const updated = tickets.map(t => t.id === id ? { ...t, ...updates } : t);
    saveTickets(updated);
  };

  const addHistorico = (ticketId: string, item: Omit<HistoricoItem, 'id'>) => {
    const ticket = tickets.find(t => t.id === ticketId);
    if (!ticket) return;

    const newItem: HistoricoItem = {
      ...item,
      id: `h-${Date.now()}`
    };

    const updatedHistorico = [...ticket.historico, newItem];
    
    const updates: Partial<Ticket> = {
      historico: updatedHistorico,
      status: item.statusNovo
    };

    if (item.statusNovo === 'CONCLUIDO') {
      updates.dataConclusao = new Date();
    }

    updateTicket(ticketId, updates);
  };

  const atribuirTicket = (ticketId: string, operador: string) => {
    updateTicket(ticketId, {
      operador,
      dataAtribuicao: new Date(),
      status: 'EM_OPERACAO'
    });
  };

  return (
    <TicketsContext.Provider value={{
      tickets,
      updateTicket,
      addHistorico,
      atribuirTicket
    }}>
      {children}
    </TicketsContext.Provider>
  );
}

export function useTickets() {
  const context = useContext(TicketsContext);
  if (!context) {
    throw new Error('useTickets must be used within TicketsProvider');
  }
  return context;
}
