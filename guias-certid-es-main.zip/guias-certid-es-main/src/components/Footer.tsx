import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t bg-foreground py-10">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-sm">
          <div>
            <h4 className="font-semibold text-primary-foreground mb-3">Consultas e Processamentos Disponíveis</h4>
            <ul className="space-y-1.5 text-muted">
              <li>Certidão de Quitação Eleitoral</li>
              <li>Antecedentes Criminais (Polícia Federal)</li>
              <li>Certidão Criminal Federal</li>
              <li>Certidão Criminal Estadual</li>
              <li>Certidão Cível Federal</li>
              <li>Certidão Cível Estadual</li>
              <li>Certidão Negativa de Débitos (CND)</li>
              <li>Certidão de CPF Regular</li>
              <li>Certidão de Débito Trabalhista</li>
              <li>CCIR - Cadastro de Imóvel Rural</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-primary-foreground mb-3">Links Úteis</h4>
            <ul className="space-y-1.5">
              <li><a href="#" className="text-muted underline hover:text-primary-foreground transition-colors">Termos de Uso</a></li>
              <li><a href="#" className="text-muted underline hover:text-primary-foreground transition-colors">Política de Privacidade</a></li>
              <li><Link to="/fale-conosco" className="text-muted underline hover:text-primary-foreground transition-colors">Fale Conosco</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-primary-foreground mb-3">Horário de Atendimento</h4>
            <p className="text-muted font-semibold mb-1">Seg – Sex: 08h às 17h30</p>
            <div className="space-y-1 text-muted mt-3">
              <p>Fale Conosco:</p>
              <a href="mailto:contato@guiadascertidoes.online" className="underline hover:text-primary-foreground transition-colors">
                contato@guiadascertidoes.online
              </a>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t border-muted-foreground/20 text-center text-xs text-muted space-y-1">
          <p>© 2025 – Guia das Certidões. Todos os Direitos Reservados.</p>
          <p>Plataforma privada de automação documental com IA.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
