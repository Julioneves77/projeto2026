import { Info } from "lucide-react";

const InfoBox = () => {
  return (
    <section className="py-12">
      <div className="container">
        <div className="max-w-3xl mx-auto bg-primary rounded-xl p-8 text-primary-foreground">
          <div className="flex items-start gap-3 mb-4">
            <Info className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <h3 className="font-bold text-lg">Importante: Somos Plataforma Privada</h3>
          </div>
          <div className="space-y-3 text-sm leading-relaxed opacity-90">
            <p>
              Somos uma <strong>plataforma privada e independente</strong> que utiliza tecnologia para processamento digital de solicitação de
              certidões usando <strong>inteligência artificial</strong> para orientar e auxiliar a automação de certidões de forma independente.
            </p>
            <p>
              <strong>NÃO somos órgão público</strong> nem possuímos vínculo direto com o Governo. Somos uma empresa de tecnologia que facilita o
              acesso às certidões.
            </p>
            <p>
              O processamento é feito de forma <strong>automática e digital</strong>. Nossos sistemas mantêm serviço de processamento 24h e 7 dias
              por semana.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InfoBox;
