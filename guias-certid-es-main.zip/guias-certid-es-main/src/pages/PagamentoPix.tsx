import { useLocation, useNavigate } from "react-router-dom";
import { QrCode, Copy, CheckCircle, Clock, ArrowLeft } from "lucide-react";
import { useState } from "react";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const FAKE_PIX_CODE = "00020126580014br.gov.bcb.pix0136a1b2c3d4-e5f6-7890-abcd-ef1234567890520400005303986540559.375802BR5925GUIA DAS CERTIDOES LTDA6009SAO PAULO62070503***6304ABCD";

const PagamentoPix = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const service = (location.state as any)?.service || "Certidão";
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(FAKE_PIX_CODE);
    setCopied(true);
    toast.success("Código PIX copiado!");
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className="flex-1 py-8">
        <div className="container max-w-lg">
          <div className="bg-card rounded-xl border p-6 md:p-10 text-center">
            {/* Title */}
            <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <QrCode className="w-8 h-8 text-accent" />
            </div>
            <h1 className="text-xl font-bold text-foreground mb-1">Pagamento via PIX</h1>
            <p className="text-sm text-muted-foreground mb-6">Escaneie o QR Code ou copie o código</p>

            {/* Document info */}
            <div className="bg-primary rounded-xl p-4 mb-6 flex items-center justify-between">
              <div className="text-left">
                <p className="text-xs text-primary-foreground/70">Documento</p>
                <p className="text-primary-foreground font-semibold text-sm">{service}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-primary-foreground/70">VALOR</p>
                <p className="text-2xl font-extrabold text-accent-foreground bg-accent rounded-lg px-3 py-1">R$ 59,37</p>
              </div>
            </div>

            {/* QR Code placeholder */}
            <div className="bg-card border-2 border-dashed border-border rounded-xl p-8 mb-6 flex flex-col items-center">
              <div className="w-48 h-48 bg-foreground rounded-lg flex items-center justify-center mb-4">
                <div className="grid grid-cols-5 gap-1 p-4">
                  {Array.from({ length: 25 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-6 h-6 rounded-sm ${
                        [0,1,2,4,5,6,8,10,12,14,16,18,20,22,24].includes(i)
                          ? "bg-primary-foreground"
                          : "bg-foreground"
                      }`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-xs text-muted-foreground">Escaneie com o app do seu banco</p>
            </div>

            {/* Copy code */}
            <div className="mb-6">
              <p className="text-sm font-medium text-foreground mb-2">Ou copie o código PIX:</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-muted rounded-lg px-4 py-3 text-xs text-muted-foreground truncate font-mono text-left">
                  {FAKE_PIX_CODE.slice(0, 50)}...
                </div>
                <Button onClick={handleCopy} variant="outline" size="sm" className="flex-shrink-0">
                  {copied ? <CheckCircle className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            {/* Timer */}
            <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 mb-6 flex items-center gap-3">
              <Clock className="w-5 h-5 text-accent flex-shrink-0" />
              <div className="text-left">
                <p className="text-sm font-semibold text-foreground">Aguardando pagamento</p>
                <p className="text-xs text-muted-foreground">O QR Code expira em 30 minutos. Após o pagamento, seu documento será processado automaticamente.</p>
              </div>
            </div>

            {/* Steps */}
            <div className="space-y-3 mb-6 text-left">
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-accent text-accent-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                <p className="text-sm text-foreground">Abra o app do seu banco e acesse a área <strong>PIX</strong></p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-accent text-accent-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                <p className="text-sm text-foreground">Escaneie o <strong>QR Code</strong> ou cole o código copiado</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-accent text-accent-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                <p className="text-sm text-foreground">Confirme o pagamento e <strong>aguarde a aprovação instantânea</strong></p>
              </div>
            </div>

            <Button variant="outline" onClick={() => navigate("/")} className="w-full">
              <ArrowLeft className="w-4 h-4 mr-2" /> Voltar para o início
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PagamentoPix;
